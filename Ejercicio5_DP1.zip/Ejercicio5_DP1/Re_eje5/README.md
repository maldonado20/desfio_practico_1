# Re_eje5
resistencia 
