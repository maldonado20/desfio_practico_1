﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio5_DP1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "\n\t Resistencias. ";

            int banda1, banda2, banda3, banda4, valor;
            double tolerencia = 0;
            Console.WriteLine("Por favor ingrese los colores de las 4 bandas de su resistencia");
            Console.WriteLine("1. Marrón");
            Console.WriteLine("2. Rojo");
            Console.WriteLine("3. Naranja");
            Console.WriteLine("4. Amarillo");
            Console.WriteLine("5. Verde");
            Console.WriteLine("6. Azul");
            Console.WriteLine("7. Morado");
            Console.WriteLine("8. Gris");
            Console.WriteLine("9. Blanco");
            Console.WriteLine("10. Dorado");
            Console.WriteLine("11. Plateado");

            Console.WriteLine("Ingrese el número de la primera banda:");
             banda1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el número de la segunda banda:");
             banda2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el número de la tercera banda:");
             banda3 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el número de la cuarta banda:");
             banda4 = int.Parse(Console.ReadLine());

             valor = (banda1 * 10 + banda2) * (int)Math.Pow(10, banda3);
           

            switch (banda4)
            {
                case 10:
                    tolerencia = 5;
                    break;
                case 11:
                    tolerencia = 10;
                    break;
                case 9:
                    tolerencia = 1;
                    break;
                case 8:
                    tolerencia = 2;
                    break;
            }

            if (valor >= 1000 && valor < 1000000)
            {
                Console.WriteLine("El valor de la resistencia es de: " + (valor / 1000.0).ToString("0.##") + " KOhm con una tolerancia del " + tolerencia.ToString("0.##") + "%");
            }
            else if (valor >= 1000000)
            {
                Console.WriteLine("El valor de la resistencia es de: " + (valor / 1000000.0).ToString("0.##") + " MOhm con una tolerancia del " + tolerencia.ToString("0.##") + "%");
            }
            else
            {
                Console.WriteLine("El valor de la resistencia es de: " + valor + " Ohm con una tolerancia del " + tolerencia.ToString("0.##") + "%");
            }

            Console.ReadLine();
        }
    }
}
